package com.myservlet.servletpkg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.Cookies;

/**
 * Servlet implementation class myserv
 */
@WebServlet("/myserv")
public class myserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public myserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		out.println("<h2> Email : </h2> <h4>" + request.getParameter("email") + "</h4>");
		out.println("<h2> Password : </h2><h4>" + request.getParameter("password") + "</h4>");
		out.println("<p> Cookie Values are displayed in console </p>");
	
		Cookie cemail = new Cookie("cemail", request.getParameter("email"));
		Cookie cpassword = new Cookie("cpassword", request.getParameter("password"));
		
		cemail.setMaxAge(10);
		cpassword.setMaxAge(10);
		
		response.addCookie(cemail);
		response.addCookie(cpassword);
		
		Cookie[] cookies =null;
		cookies= request.getCookies();
		
		if(null != cookies && cookies.length>0){
			for(int i=0; i< cookies.length;i++){
				System.out.println("Cookie Name :" + cookies[i].getName() + " , Cookie Value : " + cookies[i].getValue());
				//out.println("Cookie Name :" + cookies[i].getName() + " , Cookie Value : " + cookies[i].getValue());
			
			}
		}
		
		cemail.setMaxAge(0);
		cpassword.setMaxAge(0);
		
		response.addCookie(cemail);
		response.addCookie(cpassword);
		
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
