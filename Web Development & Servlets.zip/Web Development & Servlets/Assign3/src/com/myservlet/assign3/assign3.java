package com.myservlet.assign3;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class assign3
 */
@WebServlet("/assign3")
public class assign3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public assign3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(true);
		Date createTime= new Date(session.getCreationTime());
		Date lastAccessTime = new Date(session.getLastAccessedTime());
		
		String title = "Welcome To the World of Coding";
		int visit_count= 0;
		String visitCountKey= "visit_count";
		String userIDkey= "user ID";
		String userid= "Kriti";
		
		if(session.isNew() ){
			title = "Welcome New User";
			session.setAttribute(userIDkey, userid);
		} else{
			visit_count = (int)session.getAttribute(visitCountKey);
			visit_count += 1;
			userid = (String)session.getAttribute("userid");
		}
		
		session.setAttribute("visit_count", visit_count);
		
		out.println("Session ID : <b>" + session.getId() + "</b> <br>");
		out.println("Title : <b>" + title + "</b> <br>");
		out.println("Visit Count : <b>" + visit_count + "</b> <br>");
		out.println("Last Access Time : <b>" + lastAccessTime + " </b><br>");
		
		session.invalidate();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
